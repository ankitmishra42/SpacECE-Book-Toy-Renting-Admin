<div>
    <div class="basic-form">
        <form <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check($route)): ?> action="<?php echo e(route($route, $updateId)); ?>"<?php endif; ?> method="POST" enctype="multipart/form-data"> <?php echo csrf_field(); ?>
            <?php if($method): ?>  <?php echo method_field('put'); ?> <?php endif; ?>
            <?php echo e($slot); ?>


            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check($route)): ?>
            <div class="form-group text-right mt-3 mb-0">
                <button type="submit" class="btn btn-primary mb-2"><?php echo e(__($type)); ?></button>
            </div>
            <?php endif; ?>
        </form>
    </div>
</div>
<?php /**PATH /Users/abedin.dev/Code/Razinosft/laundrymart/resources/views/components/form.blade.php ENDPATH**/ ?>