<?php $__env->startSection('content'); ?>
    <div class="container-fluid my-4">
        <div class="row">
            <div class="col-lg-12 mb-3">
                <div class="card shadow-sm rounded-12">
                    <div class="card-body p-3">
                        <div class="d-flex align-items-center justify-content-between flex-wrap">
                            <h2 class="card-title m-0"><?php echo e(__('Shop_List')); ?></h2>
                            <div class="d-flex justify-content-end">
                                <a href="<?php echo e(route('shop.create')); ?>" class="btn btn-primary">
                                    <i class="fas fa-plus"></i> <?php echo e(__('Add_New_Shop')); ?>

                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row row-gap">
            <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-md-6 col-xl-4 col-2xl-3">
                    <div class="card shadow-sm rounded-12 show-card position-relative overflow-hidden">
                        <div class="card-body shop p-2">
                            <div class="banner">
                                <img class="img-fit" src="<?php echo e($store->banner?->file); ?>" />
                            </div>
                            <div class="main-content">
                                <div class="logo">
                                    <img class="img-fit" src="<?php echo e($store->logo?->file); ?>" />
                                </div>
                                <div class="personal">
                                    <span class="name"><?php echo e($store->name); ?></span>
                                    <span class="email"><?php echo e($store->user->email); ?></span>
                                </div>
                            </div>
                            <div class="d-flex flex-column gap-2 px-3 mt-2">
                                <div class="item">
                                    <strong><?php echo e(__('Status')); ?></strong>
                                    <label class="switch mb-0">
                                        <a href="<?php echo e(route('shop.status.toggle', $store->user->id)); ?>">
                                            <input type="checkbox" <?php echo e($store->user->is_active ? 'checked' : ''); ?>>
                                            <span class="slider round"></span>
                                        </a>
                                    </label>
                                </div>
                                <div class="item">
                                    <strong><?php echo e(__('Services')); ?></strong>
                                    <a href="<?php echo e(route('shop.service', $store->id)); ?>" class="btn btn-warning btn-sm">
                                        <i class="fas fa-cogs m-0"></i>
                                        <span class="badge badge-warning m-0">
                                            <?php echo e($store->services->count()); ?>

                                        </span>
                                    </a>
                                </div>
                                <div class="item">
                                    <strong><?php echo e(__('Products')); ?></strong>
                                    <a href="<?php echo e(route('shop.product', $store->id)); ?>" class="btn btn-primary btn-sm">
                                        <i class="fas fa-tshirt text-white m-0"></i>
                                        <span class="badge badge-warning m-0">
                                            <?php echo e($store->products->count()); ?>

                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="overlay">
                            <a class="icons" href="<?php echo e(route('shop.edit', $store->id)); ?>">
                                <i class="fa fa-edit"></i>
                            </a>
                            <a class="icons" href="<?php echo e(route('shop.show', $store->id)); ?>">
                                <i class="fa fa-eye"></i>
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <style>

    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/abedin.dev/Code/Razinosft/laundrymart/resources/views/shop/index.blade.php ENDPATH**/ ?>