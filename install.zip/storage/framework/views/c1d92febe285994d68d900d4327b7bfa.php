<?php $__env->startSection('content'); ?>
    <div class="container-fluid my-4">
        <div class="row">
            <div class="col-lg-12">
                <div class="card rounded-12 shadow border-0">
                    <div class="card-header d-flex align-items-center flex-wrap justify-content-between">
                        <h2 class="card-title m-0"><?php echo e(__('Products')); ?></h2>
                        <div>
                            <ul class="nav nav-pills justify-content-end">
                                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'store')): ?>
                                    <li class="nav-item ml-2 mr-md-0">
                                        <a href="<?php echo e(route('product.create')); ?>" class="btn btn-primary"><?php echo e(__('Add_New_Product')); ?></a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped" id="myTable">
                                <thead>
                                    <tr>
                                        <th scope="col"><?php echo e(__('Name')); ?></th>
                                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'root|admin')): ?>
                                            <th><?php echo e(__('Store_Name')); ?></th>
                                        <?php endif; ?>
                                        <th scope="col"><?php echo e(__('Thumbnail')); ?></th>
                                        <th scope="col"><?php echo e(__('Variant')); ?></th>
                                        <th scope="col"><?php echo e(__('Discount_Price')); ?></th>
                                        <th scope="col"><?php echo e(__('Price')); ?></th>
                                        <th scope="col"><?php echo e(__('Description')); ?></th>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product.status.toggle')): ?>
                                            <th scope="col"><?php echo e(__('Status')); ?></th>
                                        <?php endif; ?>
                                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'store')): ?>
                                            <th scope="col"><?php echo e(__('Action')); ?></th>
                                        <?php endif; ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($product->name); ?></td>
                                            <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'root|admin')): ?>
                                                <td><?php echo e($product->store->name); ?></td>
                                            <?php endif; ?>
                                            <td class="py-2">
                                                <div class="thumbnail">
                                                    <img width="100%" src="<?php echo e($product->thumbnailPath); ?>" alt="">
                                                </div>
                                            </td>
                                            <td><?php echo e($product->variant->name); ?></td>
                                            <td>
                                                <?php if($product->discount_price): ?>
                                                    <?php echo e(currencyPosition($product->discount_price)); ?>

                                                <?php else: ?>
                                                    <del><?php echo e(currencyPosition('00')); ?></del>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($product->discount_price): ?>
                                                    <del><?php echo e(currencyPosition($product->price ? $product->price : '00')); ?></del>
                                                <?php else: ?>
                                                    <?php echo e(currencyPosition($product->price ? $product->price : '00')); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td style="min-width: 180px">
                                                <?php echo e(Str::limit( $product->description, 60, '...')); ?>

                                            </td>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product.status.toggle')): ?>
                                                <td>
                                                    <label class="switch">
                                                        <a href="<?php echo e(route('product.status.toggle', $product->id)); ?>">
                                                            <input type="checkbox" <?php echo e($product->is_active ? 'checked' : ''); ?>>
                                                            <span class="slider round"></span>
                                                        </a>
                                                    </label>
                                                </td>
                                            <?php endif; ?>
                                            <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'store')): ?>
                                                <td>
                                                    <a href="<?php echo e(route('product.edit', $product->id)); ?>"
                                                        class="btn btn-sm btn-primary">
                                                        <i class="far fa-edit"></i>
                                                    </a>
                                                </td>
                                            <?php endif; ?>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/abedin.dev/Code/Razinosft/laundrymart/resources/views/products/index.blade.php ENDPATH**/ ?>