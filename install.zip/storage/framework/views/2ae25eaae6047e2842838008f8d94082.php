<?php $__env->startSection('content'); ?>
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-lg-12 mb-3">
                <div class="card shadow border-0 rounded-12">
                    <div class="card-header d-flex justify-content-between align-items-center py-2">
                        <h2 class="card-title m-0"><?php echo e(__('All_Variants')); ?></h2>
                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'store')): ?>
                            <button data-toggle="modal" data-target="#addNew" class="btn btn-primary">
                                <?php echo e(__('Add_New_Variant')); ?>

                            </button>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'store')): ?> table-striped <?php endif; ?>" id="myTable">
                                <thead>
                                    <tr>
                                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'root|admin')): ?>
                                            <th><?php echo e(__('Shop_Wise_Variants')); ?></th>
                                        <?php else: ?>
                                            <th><?php echo e(__('SL')); ?></th>
                                            <th><?php echo e(__('Name')); ?></th>
                                            <th><?php echo e(__('Service') . ' '. __('Name')); ?></th>
                                            <th class="text-center"><?php echo e(__('Position')); ?></th>
                                        <?php endif; ?>
                                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'store')): ?>
                                            <th><?php echo e(__('Action')); ?></th>
                                        <?php endif; ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'root|admin')): ?>
                                        <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="p-2">
                                                    <div data-toggle="collapse" data-target="#storeVariants<?php echo e($store->id); ?>" class="variantGroup">
                                                       <div class="d-flex gap-4 align-items-center" style="gap: 10px">
                                                           <span>
                                                               <img src="<?php echo e($store->logoPath); ?>" alt="" width="46" height="46">
                                                           </span>
                                                        <span><?php echo e($store->name); ?></span>
                                                       </div>
                                                       <div>
                                                        <span class="badge badge-primary"><?php echo e(count($store->variants)); ?></span>
                                                       </div>
                                                    </div>
                                                    <div class="collapse mt-2" id="storeVariants<?php echo e($store->id); ?>">
                                                        <div class="card card-body p-2">
                                                            <table class="table table-bordered">
                                                                <thead class="table-light">
                                                                    <tr>
                                                                        <th><?php echo e(__('Name')); ?></th>
                                                                        <th><?php echo e(__('Service') . ' '. __('Name')); ?></th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    <?php $__currentLoopData = $store->variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <tr>
                                                                        <td><?php echo e($variant->name); ?></td>
                                                                        <td><?php echo e($variant->service?->name); ?></td>
                                                                    </tr>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <?php $__currentLoopData = $variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e(++$key); ?></td>
                                                <td><?php echo e($variant->name); ?></td>
                                                <td><?php echo e($variant->service?->name); ?></td>
                                                <td class="text-center"><?php echo e($variant->position ?? 0); ?></td>
                                                <td>
                                                    <div class="d-flex gap-2">
                                                        <button type="button" class="btn btn-primary" data-toggle="modal"
                                                        data-target="#update<?php echo e($variant->id); ?>">
                                                            <i class="far fa-edit"></i>
                                                        </button>

                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('variant.products')): ?>
                                                        <a href="<?php echo e(route('variant.products', $variant->id)); ?>"
                                                            class="btn btn-info"><?php echo e(__('Products')); ?></a>
                                                        <?php endif; ?>
                                                    </div>
                                                    <!-- Modal -->
                                                    <div class="modal fade" id="update<?php echo e($variant->id); ?>">
                                                        <div class="modal-dialog">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h2 class="modal-title" id="exampleModalLabel">
                                                                        <?php echo e(__('Edit_Variant')); ?>

                                                                    </h2>
                                                                    <button type="button" class="close" data-dismiss="modal"
                                                                        aria-label="Close">
                                                                        <span aria-hidden="true">&times;</span>
                                                                    </button>
                                                                </div>
                                                                <form action="<?php echo e(route('variant.update', $variant->id)); ?>"
                                                                    method="POST">
                                                                    <?php echo csrf_field(); ?> <?php echo method_field('put'); ?>
                                                                    <div class="modal-body">
                                                                        <div class="mb-3">
                                                                            <label><?php echo e(__('Name')); ?></label>
                                                                            <input type="text" name="name"
                                                                                class="form-control"
                                                                                value="<?php echo e(old('name') ?? $variant->name); ?>">
                                                                        </div>

                                                                        <div class="mb-3">
                                                                            <label class="mb-1">
                                                                                <?php echo e(__('Service')); ?>

                                                                            </label>
                                                                            <?php if (isset($component)) { $__componentOriginalbf566fc26595b9cc6779e170beef8a5a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbf566fc26595b9cc6779e170beef8a5a = $attributes; } ?>
<?php $component = App\View\Components\Select::resolve(['name' => 'service_id'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Select::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                                                                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <option value="<?php echo e($service->id); ?>"
                                                                                        <?php echo e($variant->service_id == $service->id ? 'selected' : ''); ?>>
                                                                                        <?php echo e($service->name); ?>

                                                                                    </option>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbf566fc26595b9cc6779e170beef8a5a)): ?>
<?php $attributes = $__attributesOriginalbf566fc26595b9cc6779e170beef8a5a; ?>
<?php unset($__attributesOriginalbf566fc26595b9cc6779e170beef8a5a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbf566fc26595b9cc6779e170beef8a5a)): ?>
<?php $component = $__componentOriginalbf566fc26595b9cc6779e170beef8a5a; ?>
<?php unset($__componentOriginalbf566fc26595b9cc6779e170beef8a5a); ?>
<?php endif; ?>
                                                                        </div>

                                                                        <div class="mb-3">
                                                                            <label><?php echo e(__('Position')); ?></label>
                                                                            <input type="text" name="position"
                                                                                class="form-control"
                                                                                value="<?php echo e(old('position') ?? $variant->position); ?>"
                                                                                placeholder="Position">
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-secondary"
                                                                            data-dismiss="modal"><?php echo e(__('Close')); ?></button>
                                                                        <button type="submit" class="btn btn-primary">
                                                                            <?php echo e(__('Save_changes')); ?>

                                                                        </button>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'store')): ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('variant.store')): ?>
            <!-- Modal -->
            <div class="modal fade" id="addNew">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h3 class="modal-title" id="exampleModalLabel"><?php echo e(__('Add_New_Variant')); ?></h3>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form action="<?php echo e(route('variant.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="modal-body">
                                <div class="mb-3">
                                    <?php echo e(__('Name')); ?>

                                    <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>"
                                        placeholder="Variant Name">
                                </div>
                                <div class="mb-3">
                                    <label class="mb-1"><?php echo e(__('Service')); ?></label>
                                    <?php if (isset($component)) { $__componentOriginalbf566fc26595b9cc6779e170beef8a5a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbf566fc26595b9cc6779e170beef8a5a = $attributes; } ?>
<?php $component = App\View\Components\Select::resolve(['name' => 'service_id'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Select::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($service->id); ?>"><?php echo e($service->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbf566fc26595b9cc6779e170beef8a5a)): ?>
<?php $attributes = $__attributesOriginalbf566fc26595b9cc6779e170beef8a5a; ?>
<?php unset($__attributesOriginalbf566fc26595b9cc6779e170beef8a5a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbf566fc26595b9cc6779e170beef8a5a)): ?>
<?php $component = $__componentOriginalbf566fc26595b9cc6779e170beef8a5a; ?>
<?php unset($__componentOriginalbf566fc26595b9cc6779e170beef8a5a); ?>
<?php endif; ?>
                                </div>

                                <div class="mb-3">
                                    <label><?php echo e(__('Position')); ?></label>
                                    <input type="text" name="position" class="form-control" value="<?php echo e(old('position')); ?>"
                                        placeholder="Position">
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('Close')); ?></button>
                                <button type="submit" class="btn btn-primary"><?php echo e(__('Submit')); ?></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/abedin.dev/Code/Razinosft/laundrymart/resources/views/variants/index.blade.php ENDPATH**/ ?>