<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="header pt-5">

        <div class="header-body mt--4">
            <div class="row align-items-center pb-4">
                <div class="col-lg-6 col-7">
                    <h6 class="h2 d-inline-block"><?php echo e(__('Dashboard')); ?></h6>
                    <nav aria-label="breadcrumb" class="d-none d-md-inline-block">
                        <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                            <li class="breadcrumb-item "><a href="<?php echo e(route('root')); ?>"><i class="fa fa-home text-primary"></i></a></li>
                            <li class="breadcrumb-item active" aria-current="page"> <?php echo e(__('Dashboard')); ?> </li>
                        </ol>
                    </nav>
                </div>
            </div>

            <!-- Card stats -->
            <div class="row">
                <div class="col-xl-3 col-lg-6">
                    <div class="card card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col mt-3 text-right">
                                    <h4 class="card-title text-uppercase text-muted mb-0"><?php echo e(__('Shops')); ?></h4>
                                    <span class="display-3 text-dark font-weight-bold mb-0">
                                        <?php echo e($shop); ?>

                                    </span>
                                </div>
                                <div class="card-icon">
                                    <div class="icon icon-shape text-white shadow">
                                        <img width="70" src="<?php echo e(asset('images/icons/shop.png')); ?>" alt="">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-lg-6">
                    <div class="card card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col mt-3 text-right">
                                    <h4 class="card-title text-uppercase text-muted mb-0"><?php echo e(__('Products')); ?></h4>
                                    <span class="display-3 text-dark font-weight-bold mb-0">
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dashboard.calculation')): ?>
                                        <?php echo e($products->count()); ?>

                                        <?php else: ?>
                                        00
                                        <?php endif; ?>
                                    </span>
                                </div>
                                <div class="card-icon">
                                    <div class="icon icon-shape text-white shadow">
                                        <img width="80" src="<?php echo e(asset('images/icons/items.svg')); ?>" alt="">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-lg-6">
                    <div class="card card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col mt-3 text-right">
                                    <h4 class="card-title text-uppercase text-muted mb-0"><?php echo e(__('Services')); ?></h4>
                                    <span class="display-3 text-dark font-weight-bold mb-0">
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dashboard.calculation')): ?>
                                        <?php echo e($services->count()); ?>

                                        <?php else: ?>
                                        00
                                        <?php endif; ?>
                                    </span>
                                </div>
                                <div class="card-icon">
                                    <div class="icon icon-shape text-white shadow">
                                        <img width="80" src="<?php echo e(asset('images/icons/services.svg')); ?>" alt="">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<div class="container-fluid mt-4">
    <div class="row">
        <div class="col-12 col-2xl-8">

            <div class="card p-3">
                <div class="">
                    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
                        <h3 class="m-0"><?php echo e(__('Revenue')); ?></h3>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('revenue.index')): ?>
                            <div>
                                <div class="dropdown">
                                    <button class="btn btn-secondary py-1 dropdown-toggle" type="button" id="filter-revunue" data-toggle="dropdown" aria-expanded="false">
                                        <?php echo e(ucfirst(\request()->type) ? __(ucfirst(\request()->type)) : __('Today')); ?>

                                    </button>

                                    <div class="dropdown-menu" aria-labelledby="filter-revunue">
                                        <a class="dropdown-item" href="<?php echo e(route('root', ['type' => 'today'])); ?>"><?php echo e(__('Today')); ?></a>
                                        <a class="dropdown-item" href="<?php echo e(route('root', ['type' => 'week'])); ?>"><?php echo e(__('Week')); ?></a>
                                        <a class="dropdown-item" href="<?php echo e(route('root', ['type' => 'month'])); ?>"><?php echo e(__('This_Month')); ?></a>
                                        <a class="dropdown-item" href="<?php echo e(route('root', ['type' => 'year'])); ?>"><?php echo e(__('This_Year')); ?></a>
                                    </div>
                                </div>
                                <?php
                                    $type = ucfirst(\request()->type) ? ucfirst(\request()->type) : '';
                                ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('revenue.generate.pdf')): ?>
                                    <a class="btn py-1 text-white btn-primary"
                                        href="<?php echo e(route('revenue.generate.pdf', ['type' => strtolower($type)])); ?>" target="_blank">
                                        <i class="fas fa-file-download mr-1"></i> <?php echo e(__('Download')); ?>

                                    </a>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <hr class="my-3">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th scope="col"><?php echo e(__('Delivery_Date')); ?></th>
                                <th scope="col"><?php echo e(__('Order_By')); ?></th>
                                <th scope="col"><?php echo e(__('Quantity')); ?></th>
                                <th scope="col"><?php echo e(__('Total')); ?></th>
                                <th scope="col"><?php echo e(__('Action')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dashboard.revenue')): ?>
                            <?php $__empty_1 = true; $__currentLoopData = $revenues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revenue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td>
                                        <?php echo e(Carbon\Carbon::parse($revenue->delivery_date)->format('M d, Y')); ?>

                                    </td>
                                    <td><?php echo e($revenue->customer->user->name); ?></td>
                                    <td><?php echo e($revenue->products->sum('pivot.quantity')); ?> <?php echo e(__('Pieces')); ?></td>
                                    <td><?php echo e(currencyPosition($revenue->payable_amount)); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('order.show', $revenue->id)); ?>" class="btn btn-primary"><?php echo e(__('Details')); ?></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr class="text-center">
                                    <td colspan="5"><?php echo e(__('Sorry')); ?>, <?php echo e(ucfirst(\request()->type) ? __(ucfirst(\request()->type)) : __('Today')); ?> <?php echo e(__('revenue_not_found')); ?></td>
                                </tr>
                            <?php endif; ?>
                            <?php else: ?>
                            <tr class="text-center">
                                <td colspan="5"><?php echo e(__('Sorry').', '. ucfirst(\request()->type) ? __(ucfirst(\request()->type)) : __('Today')); ?> <?php echo e(__('revenue_not_found')); ?></td>
                            </tr>
                            <?php endif; ?>
                            <tr>
                                <td colspan="3" class="text-right"><?php echo e(__('Total_Revenue')); ?></td>
                                <td colspan="2"><?php echo e(currencyPosition($revenues->sum('amount'))); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>

        <div class="col-12 col-2xl-4 mt-3 mt-2xl-0">
            <div class="card" style="border-radius: 10px; border-bottom: 4px solid #39D8D8;">
                <div class="overview">
                    <img width="100%" src="<?php echo e(asset('web/bg/overview.svg')); ?>" alt="">
                    <div>
                        <h2 class="text-white"><?php echo e(__('Overview')); ?></h2>
                    </div>
                </div>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dashboard.overview')): ?>
                <div class="row p-3">
                    <div class="col-2xl-6 col-md-4 col-6 mb-3">
                        <img width="50" src="<?php echo e(asset('images/icons/users.svg')); ?>" class="float-left mr-2" alt="">
                        <div>
                            <h3 class="m-0 text-dark"><?php echo e($customers->count()); ?></h3>
                            <span class="txt-1"><?php echo e(__('Users')); ?></span>
                        </div>
                    </div>
                    <div class="col-2xl-6 col-md-4 col-6 mb-3">
                        <img width="50" src="<?php echo e(asset('images/icons/Orders.svg')); ?>" class="float-left mr-2" alt="">
                        <div>
                            <h3 class="m-0 text-dark"><?php echo e($confirmOrder); ?></h3>
                            <span class="txt-1"><?php echo e(__('Orders')); ?></span>
                        </div>
                    </div>
                    <div class="col-2xl-6 col-md-4 col-6 mb-3">
                        <img width="50" src="<?php echo e(asset('images/icons/Pending.svg')); ?>" class="float-left mr-2" alt="">
                        <div>
                            <h3 class="m-0 text-dark"><?php echo e($pendingOrder); ?></h3>
                            <span class="txt-1"><?php echo e(__('Pending')); ?></span>
                        </div>
                    </div>
                    <div class="col-2xl-6 col-md-4 col-6 mb-3">
                        <img width="50" src="<?php echo e(asset('images/icons/progress.svg')); ?>" class="float-left mr-2" alt="">
                        <div>
                            <h3 class="m-0 text-dark"><?php echo e($onPregressOrder); ?></h3>
                            <span class="txt-1"><?php echo e(__('On_progress')); ?></span>
                        </div>
                    </div>
                    <div class="col-2xl-6 col-md-4 col-6">
                        <img width="50" src="<?php echo e(asset('images/icons/delivered.svg')); ?>" class="float-left mr-2" alt="">
                        <div>
                            <h3 class="m-0 text-dark"><?php echo e($completeOrder); ?></h3>
                            <span class="txt-1"><?php echo e(__('Delivered')); ?></span>
                        </div>
                    </div>
                    <div class="col-2xl-6 col-md-4 col-6 ">
                        <img width="50" src="<?php echo e(asset('images/icons/order.svg')); ?>" class="float-left mr-2" alt="">
                        <div>
                            <h3 class="m-0 text-dark"><?php echo e($cancelledOrder); ?></h3>
                            <span class="txt-1"><?php echo e(__('Cancel_Order')); ?></span>
                        </div>
                    </div>
                </div>
                <?php else: ?>
                <div class="row p-3">
                    <div class="col-2xl-6 col-md-4 col-6 mb-3">
                        <img width="50" src="<?php echo e(asset('images/icons/users.svg')); ?>" class="float-left mr-2" alt="">
                        <div>
                            <h3 class="m-0 text-dark">00</h3>
                            <span class="txt-1"><?php echo e(__('Users')); ?></span>
                        </div>
                    </div>
                    <div class="col-2xl-6 col-md-4 col-6 mb-3">
                        <img width="50" src="<?php echo e(asset('images/icons/Orders.svg')); ?>" class="float-left mr-2" alt="">
                        <div>
                            <h3 class="m-0 text-dark">00</h3>
                            <span class="txt-1"><?php echo e(__('Orders')); ?></span>
                        </div>
                    </div>
                    <div class="col-2xl-6 col-md-4 col-6 mb-3">
                        <img width="50" src="<?php echo e(asset('images/icons/Pending.svg')); ?>" class="float-left mr-2" alt="">
                        <div>
                            <h3 class="m-0 text-dark">00</h3>
                            <span class="txt-1"><?php echo e(__('Pending')); ?></span>
                        </div>
                    </div>
                    <div class="col-2xl-6 col-md-4 col-6 mb-3">
                        <img width="50" src="<?php echo e(asset('images/icons/progress.svg')); ?>" class="float-left mr-2" alt="">
                        <div>
                            <h3 class="m-0 text-dark">00</h3>
                            <span class="txt-1"><?php echo e(__('On_progress')); ?></span>
                        </div>
                    </div>
                    <div class="col-2xl-6 col-md-4 col-6">
                        <img width="50" src="<?php echo e(asset('images/icons/delivered.svg')); ?>" class="float-left mr-2" alt="">
                        <div>
                            <h3 class="m-0 text-dark">00</h3>
                            <span class="txt-1"><?php echo e(__('Delivered')); ?></span>
                        </div>
                    </div>
                    <div class="col-2xl-6 col-md-4 col-6 ">
                        <img width="50" src="<?php echo e(asset('images/icons/order.svg')); ?>" class="float-left mr-2" alt="">
                        <div>
                            <h3 class="m-0 text-dark">00</h3>
                            <span class="txt-1"><?php echo e(__('Cancel_Order')); ?></span>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/abedin.dev/Code/Razinosft/laundrymart/resources/views/dashboard/root.blade.php ENDPATH**/ ?>