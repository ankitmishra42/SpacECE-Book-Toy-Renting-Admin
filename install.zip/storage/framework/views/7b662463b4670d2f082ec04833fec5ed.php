<?php
    $appSetting = App\Models\AppSetting::first();
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Fav icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e($appSetting?->websiteFaviconPath ?? asset('web/logo.png')); ?>">
    <!-- custome css -->
    <link rel="stylesheet" href="<?php echo e(asset('web/css/login.css')); ?>">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('web/css/bootstrap.css')); ?>">
    <!-- Font awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('web/css/all.min.css')); ?>">
    <title><?php echo e(config('app.name')); ?> Log In</title>
</head>

<body>

    <!-- Login-Section -->
    <section class="login-section">
        <form role="form" class="pui-form pt-md-5" id="loginform" method="POST" action="<?php echo e(route('login')); ?>"> <?php echo csrf_field(); ?>
            <div class="card loginCard">
                <div class="logo-section">
                    <img src="<?php echo e($appSetting?->websiteLogoPath ?? asset('web/logo.png')); ?>" alt="" width="100%">
                </div>
                <div class="card-body">
                    <div class="page-content text-center">
                        <h2 class="pageTitle mb-3">Dashboard Login</h2>
                        <p class="pagePera">Hay, Enter your details to get login to your account</p>
                    </div>

                    <div class="form-outline form-white mb-4">
                        <input type="text" name="email" id="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            value="<?php echo e(old('email')); ?>" placeholder="Email">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-outline form-white mb-3">
                        <div class="position-relative passwordInput">
                            <input type="password" name="password" id="password"
                                class="form-control py-2 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                placeholder="Password">
                            <span class="eye" onclick="showHidePassword()">
                                <i class="far fa-eye-slash fa-eye" id="togglePassword"></i>
                            </span>
                        </div>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <?php if(config('app.env') == 'local'): ?>
                    <button onclick="copy()" class="btn btn-sm btn-primary bgBlue w-100" type="button">
                        Click to copy credentials
                    </button>
                    <?php endif; ?>

                    <style>
                        .bgBlue {
                            background: #2c9de4;
                            color: #fff !important;
                        }
                    </style>

                    <button type="submit" class="btn loginButton" type="submit">Login</button>

                </div>
            </div>
        </form>
    </section>
    <!--End-Login-Section -->

    <script src="<?php echo e(asset('web/js/jquery.min.js')); ?>"></script>
    <script>
        function showHidePassword() {
            const toggle = document.getElementById("togglePassword");
            const password = document.getElementById("password");

            // toggle the type attribute
            const type = password.getAttribute("type") === "password" ? "text" : "password";
            password.setAttribute("type", type);
            // toggle the icon
            toggle.classList.toggle("fa-eye-slash");
        }

        function copy() {
            $('#email').val('root@laundrymart.com');
            $('#password').val('secret@123');
        }
    </script>

</body>

</html>
<?php /**PATH /Users/abedin.dev/Code/Razinosft/laundrymart/resources/views/auth/login.blade.php ENDPATH**/ ?>